package com.cts.training.companyservice;

import org.springframework.data.jpa.repository.JpaRepository;


public interface CompanyDAO extends JpaRepository<Company, Integer>{

}
